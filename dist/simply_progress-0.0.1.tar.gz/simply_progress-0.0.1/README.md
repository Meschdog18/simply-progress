# simply-progress
A light and easy to use progress bar for python
